#install.packages("leaflet")

library(leaflet)

library(ggplot2)

library(leafpop)


leaflet() %>%
  addTiles() %>%
  setView(lng = -93.65, lat = 42.0285, zoom = 17)

leaflet() %>%
  addTiles() %>%  # Add default OpenStreetMap map tiles
  addMarkers(lng=174.768, lat=-36.852, popup="The birthplace of R")

leaflet() %>%
  addTiles() %>%
  addMarkers(lng = c(-93.65, -93.70), lat = c(42.0285, 42.0385),
             popup = c("Location 1", "Location 2"))


leaflet() %>%
  addTiles() %>%
  setView(lng = -3.7, lat = 40.4, zoom = 5) %>%
  addMarkers(data = data.frame(lng = c(-3.7, -8, -4.2), lat = c(40.4, 43.1, 41.4))) 

circles <- data.frame(lng = c(23.59, 34.95, 17.47),
                      lat = c(-3.53, -6.32, -12.24))

leaflet() %>%
  addTiles() %>%
  addCircleMarkers(data = circles, color = "red",
                   fillColor = "red", fillOpacity = 0.2)




circles <- data.frame(lng = c(-73.58, -73.46), lat = c(45.5, 45.55))

leaflet() %>%
  addTiles() %>%
  setView(lng = -73.53, lat = 45.5, zoom = 12) %>%
  addCircles(data = circles, radius = 2000,
             popup = paste0("Title", "<hr>", "Text 1", "<br>", "Text 2")) 


p <- ggplot(mtcars, aes(x = wt, y = mpg)) +
  geom_point() +
  labs(title = "Scatter Plot of wt vs mpg") +
  theme_minimal()


leaflet() %>%
  addTiles() %>%
  setView(lng = -73.53, lat = 45.5, zoom = 12) %>%
  addCircleMarkers(data = circles,
                 popup = popupGraph(p, width = 200, height = 200))


leaflet() %>%
  addTiles() %>%
  addPolygons(lng = c(-93.65, -93.60, -93.55),
              lat = c(42.0285, 42.0350, 42.0285),
              fillColor = "blue",
              color = "black",
              weight = 2,
              opacity = 0.7,
              fillOpacity = 0.5,
              popup = "Polygon Area")


# Load the sf package
library(sf)

# Read a shapefile using st_read
# Replace 'path_to_your_shapefile.shp' with the actual path to your shapefile
sf_object <- st_read("District.shp")

shapefile_transformed <- st_transform(sf_object, crs = 4326)

leaflet(data = shapefile_transformed) %>%
  addProviderTiles("CartoDB.Positron",
                   options = providerTileOptions(opacity = 0)) %>%
  #addTiles() %>%  # Add a tile layer
  addPolygons(
    color = "black",      # Border color
    weight = 2,          # Border width
    opacity = 1,         # Border opacity
    fillColor = "green", # Fill color
    fillOpacity = 1,   # Fill opacity
    popup = ~paste0("District: ", KGISDistri) # Replace 'NAME' with the column name for district names
  )

qpal <- colorQuantile("YlGn", shapefile_transformed$SHAPE_STAr, n = 4)

leaflet(data = shapefile_transformed) %>%
  addProviderTiles("CartoDB.Positron",
                   options = providerTileOptions(opacity = 0)) %>%
  #addTiles() %>%  # Add a tile layer
  addPolygons(
    color = "black",      # Border color
    label =  ~as.character(KGISDist_1),
    labelOptions = labelOptions(
      noHide = FALSE,      # Keeps the labels always visible
      direction = "auto", # Automatically positions the label
      textsize = "12px",  # Adjusts label text size
      style = list("font-weight" = "bold", "color" = "black") # Optional: Style customization
    ),
    weight = 2,          # Border width
    opacity = 1,         # Border opacity
    fillColor = ~qpal(SHAPE_STAr), # Fill color
    fillOpacity = 1,   # Fill opacity
    popup = paste("<b style='font-size:14px;'>District:</b> ", shapefile_transformed$KGISDist_1, "<br>")
  ) %>%
addControl(
    html = "<h3>District Map</h3>", # HTML content for the title
    position = "topright"           # Position of the title
  )


